(async () => {
	switch (command) {
		case "rpussy": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var rpussyd = "Pussy Porn HD PICS";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschemas = zerogroup.nsfw || "false";
			gis(rpussyd, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*----「 Real PUSSY 」----*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `Secktor-NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschemas == "false") return citel.reply("*NSFW* is not active.");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "solo": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var futq = "SOLO Anime Porn HD PICS";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschematj = zerogroup.nsfw || "false";
			gis(futq, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*-------「 SOLO」-------*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschematj == "false") return citel.reply("*NSFW* is not active.");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "ranal": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                  prefix + command
                }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var ranal = "Anal Porn HD PICS";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschemax = zerogroup.nsfw || "false";
			gis(ranal, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*----「 Real-Anal 」----*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `Secktor-NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschemax == "false") return citel.reply("*NSFW* is not active.");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "rboobs": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var boobsd = "tits oily Porn HD PICS";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschemag = zerogroup.nsfw || "false";
			gis(boobsd, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*----「 RealBoobs 」----*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `Secktor-NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschemag == "false") return citel.reply("*NSFW* is not active.");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "cosplay": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                  prefix + command
                }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var pictureg = "ULTRA HD cosplay  porn";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschematv = zerogroup.nsfw || "false";
			gis(pictureg, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*-------「 COSPLAY 」-------*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `Secktor-NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschematv == "false") return citel.reply("*NSFW* is not active.");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "ecchi": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var picturef = "ecchi porn hd wallpaper";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschematt = zerogroup.nsfw || "false";
			gis(picturef, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*-------「 ECCHI 」-------*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschematt == "false") return citel.reply("*NSFW* is not active");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "sister":
		case "tits":
		case "mouth":
		case "lick":
		case "fingering":
		case "fisting":
		case "foot":
		case "panties":
		case "tushy":
		case "school":
		case "pussy":
		case "anal":
		case "slut":
		case "boobs":
		case "nurse":
		case "maid":
		case "hentai":
		case "milf": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var pictured = "Anime Porn HD ";
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschema = zerogroup.nsfw || "false";
			let gis = require("g-i-s");
			gis(command + pictured, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*-------「 Take it,you prevert 」-------*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				if (mongoschema == "false") return citel.reply("*NSFW* is not active");
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "highschool": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Highschool DXD pic at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var fuyq = "Highschool DXD hd Porn HD";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			//		let mongoschemat = zerogroup.nsfw || "false"
			gis(fuyq, async (error, result) => {
				n = result;
				images = n[Math.floor(Math.random() * n.length)].url;
				let buttonMessage = {
					image: {
						url: images,
					},
					caption: `*---「 HIGHSCHOOL DXD」---*`,
					footer: Void.user.name,
					headerType: 4,
					contextInfo: {
						externalAdReply: {
							title: LangG.title,
							body: `NSFW`,
							thumbnail: log0,
							mediaType: 2,
							mediaUrl: ``,
							sourceUrl: ``,
						},
					},
				};
				//		if (hht == 'false') return citel.reply("*NSFW* is not active ${LangG.greet}")
				Void.sendMessage(citel.chat, buttonMessage, {
					quoted: citel,
				});
			});
		}
		break;
		case "vixen": {
			if (querie === "help") {
				await citel.reply(`*❗Command:*   NSFW\n*🍀Aliases* ${command}\n*🧩Category:* Search\n*🛠️Usage:* ${
                prefix + command
              }\n\n*📚Description:* Send one Hot Nsfw from vixen at chat.`);
				return;
			}
			if (!isGroup) return citel.reply("*This Feature is only available for group.*");
			var picture = "Vixen Porn HD PICS";
			let gis = require("g-i-s");
			let zerogroup = (await sck.findOne({
				id: citel.chat,
			})) || (await new sck({
					id: citel.chat,
				})
				.save());
			let mongoschemat = zerogroup.nsfw || "false";
			let name1 = querie.split("|")[0]
			let name2 = querie.split("|")[1] || `1`
			let nn = name2
			for (let i = 0; i < nn; i++) {
				gis(picture, async (error, result) => {
					n = result;
					images = n[Math.floor(Math.random() * n.length)].url;
					let buttonMessage = {
						image: {
							url: images,
						},
						caption: `*-------「 VIXEN」-------*`,
						footer: Void.user.name,
						headerType: 4,
						contextInfo: {
							externalAdReply: {
								title: LangG.title,
								body: `NSFW`,
								thumbnail: log0,
								mediaType: 2,
								mediaUrl: ``,
								sourceUrl: ``,
							},
						},
					};
					if (mongoschemat == "false") return citel.reply("*NSFW* is not active");
					Void.sendMessage(citel.chat, buttonMessage, {
						quoted: citel,
					});
				});
			}
		}
		break;
	}
})()
