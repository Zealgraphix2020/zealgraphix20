apt-get update && apt-get upgrade
apt-get install git -y
apt-get install nodejs -y
apt-get install ffmpeg -y
apt-get install imagemagick -y
apt-get install yarn
git clone https://github.com/Secktorbot/Secktor-Md
cd Secktor-Md
npm start
